module com.example.flappybird {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires org.kordamp.bootstrapfx.core;
    requires javafx.media;

    opens com.example.flappybird to javafx.fxml;
    exports com.example.flappybird;
}
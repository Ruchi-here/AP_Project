package com.example.flappybird;

import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Rectangle;

import java.util.ArrayList;

public class Bird {

    //private Rectangle bird;
    private ImageView birdImage;
    private int jumpHeight;
    private double jumpSpeed = 5.0; // Adjust as needed
    private double gravity = 0.2;   // Adjust as needed
    private long jumpStartTime;
    CollisionHandler collisionHandler = new CollisionHandler();
    private double movementVariable = 2.0;

    public Bird(ImageView birdImage, int jumpHeight) {
        this.birdImage = birdImage;
        this.jumpHeight = jumpHeight;
    }

    public void moveLeft(double speed) {
        double currentX = birdImage.getLayoutX();
        birdImage.setLayoutX(currentX - speed);
    }

    public void moveRight(double speed) {
        double currentX = birdImage.getLayoutX();
        birdImage.setLayoutX(currentX + speed);
    }

    public void moveUp(double speed) {
        double currentY = birdImage.getLayoutY();
        birdImage.setLayoutY(currentY - speed);
    }

    public void moveDown(double speed) {
        double currentY = birdImage.getLayoutY();
        birdImage.setLayoutY(currentY + speed);
    }

    public boolean isBirdDead(ArrayList<Rectangle> obstacles, AnchorPane plane){
        double birdY = birdImage.getLayoutY() + birdImage.getY();

        if(collisionHandler.collisionDetection(obstacles, birdImage)){
            return  true;
        }

        return birdY >= plane.getHeight();
    }

//    private boolean onStick = false;
//    private double stickLength = 0;
//
//    public void startStick() {
//        onStick = true;
//    }
//
//    public void endStick() {
//        onStick = false;
//        stickLength = 0;
//    }
//
//    public void updateStick() {
//        if (onStick) {
//            stickLength += 2; // Adjust the value based on your preference
//            // Restrict stick length based on the game constraints if needed
//        }
//    }
//
//    public double getStickLength() {
//        return stickLength;
//    }

}
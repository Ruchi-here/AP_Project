package com.example.flappybird;

import javafx.animation.AnimationTimer;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class Controller implements Initializable {

    AnimationTimer gameLoop;
    MediaPlayer mediaPlayer;

    @FXML
    private AnchorPane plane;

    @FXML
    private ImageView runner;

    @FXML
    private Text score;


    //private double accelerationTime = 0;
    private int gameTime = 0;
    private int scoreCounter = 0;

    private Bird birdComponent;
    private ObstaclesHandler obstaclesHandler;

    private ArrayList<Rectangle> obstacles = new ArrayList<>();
    private ArrayList<Rectangle> sticks = new ArrayList<>();
    private long spaceKeyPressTime = 0;

    private MovementController movementController = new MovementController();
    private boolean isLeftKeyPressed = false;
    private boolean isRightKeyPressed = false;
    private boolean isUpKeyPressed = false;
    private boolean isDownKeyPressed = false;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        birdComponent = new Bird(runner, 10);
        movementController.makeMovable(runner, plane);
        double planeHeight = 600;
        double planeWidth = 400;
        obstaclesHandler = new ObstaclesHandler(plane, planeHeight, planeWidth);

        gameLoop = new AnimationTimer() {
            @Override
            public void handle(long l) {
                update();
            }
        };

        load();

        gameLoop.start();

        playMusic();

    }

    private void playMusic() {
        String musicPath = "music.mp3";

        // Create a Media object
        Media media = new Media(getClass().getResource("/" + musicPath).toExternalForm());
        mediaPlayer = new MediaPlayer(media);
        mediaPlayer.setCycleCount(MediaPlayer.INDEFINITE);
        mediaPlayer.play();
    }

    @FXML
    void pressed(KeyEvent event) {
        double movementSpeed = 5.0;

        if (event.getCode() == KeyCode.LEFT) {
            birdComponent.moveLeft(movementSpeed);
        } else if (event.getCode() == KeyCode.RIGHT) {
            birdComponent.moveRight(movementSpeed);
        } else if (event.getCode() == KeyCode.UP) {
            birdComponent.moveUp(movementSpeed);
        } else if (event.getCode() == KeyCode.DOWN) {
            birdComponent.moveDown(movementSpeed);
        }
    }

    @FXML
    void keyPressed(KeyEvent event) {
        handleKeyInput(event, true);
    }

    @FXML
    void keyReleased(KeyEvent event) {
        handleKeyInput(event, false);
    }

    private void handleKeyInput(KeyEvent event, boolean isPressed) {
        KeyCode code = event.getCode();
        if (code == KeyCode.LEFT) {
            isLeftKeyPressed = isPressed;
        } else if (code == KeyCode.RIGHT) {
            isRightKeyPressed = isPressed;
        } else if (code == KeyCode.UP) {
            isUpKeyPressed = isPressed;
        } else if (code == KeyCode.DOWN) {
            isDownKeyPressed = isPressed;
        }
    }


    //Called every game frame
    private void update() {
        gameTime++;
        //accelerationTime++;
        double yDelta = 0.02;

        if(pointChecker(obstacles, runner)){
            scoreCounter++;
            score.setText(String.valueOf(scoreCounter));
        }

        obstaclesHandler.moveObstacles(obstacles);
        if(gameTime % 500 == 0){
            obstacles.addAll(obstaclesHandler.createObstacles());
            //obstacles.addAll(obstaclesHandler.createObstacles(birdComponent.getStickLength()));
        }

        if(birdComponent.isBirdDead(obstacles, plane)){
            resetGame();
        }
    }

    private void removeInitialRectangle() {
        plane.getChildren().removeIf(node -> node instanceof Rectangle && ((Rectangle) node).getY() + ((Rectangle) node).getHeight() == plane.getHeight());
    }

    //Everything called once, at the game start
    private void load() {
        double planeHeight = 600;
        double rectangleHeight = 50; // Adjust the height of the rectangle as needed
        Rectangle initialRectangle = new Rectangle(58, planeHeight - rectangleHeight, 100, rectangleHeight);
        plane.getChildren().add(initialRectangle);

        obstacles.addAll(obstaclesHandler.createObstacles());
    }

    private void resetGame(){
        runner.setY(0);
        plane.getChildren().removeAll(obstacles);
        obstacles.clear();
        gameTime = 0;
        //accelerationTime = 0;
        scoreCounter = 0;
        score.setText(String.valueOf(scoreCounter));
    }



    private boolean pointChecker(ArrayList<Rectangle> obstacles, ImageView bird){
        for (Rectangle obstacle: obstacles) {
            int birdPositionX = (int) (bird.getLayoutX() + bird.getX());
            if(((int)(obstacle.getLayoutX() + obstacle.getX()) == birdPositionX)){
                return true;
            }
        }
        return false;
    }

}
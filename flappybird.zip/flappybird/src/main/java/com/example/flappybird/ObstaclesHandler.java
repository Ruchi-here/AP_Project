package com.example.flappybird;

import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Rectangle;

import java.util.*;

public class ObstaclesHandler {

    private AnchorPane plane;
    private double planeHeight;
    private double planeWidth;
    Random random = new Random();

    public ObstaclesHandler(AnchorPane plane, double planeHeight, double planeWidth) {
        this.plane = plane;
        this.planeHeight = planeHeight;
        this.planeWidth = planeWidth;
    }

    public ArrayList<Rectangle> createObstacles() {
        int minWidth = 100;
        int maxWidth = 130;
        int width = random.nextInt(maxWidth - minWidth + 1) + minWidth;
        double xPos = planeWidth;
        double space = 50;
        double recTopHeight = random.nextInt((int) (planeHeight - space - 100)) + 70;
        double recBottomHeight = planeHeight - space - recTopHeight;

        //                                     x      y   width   height
        Rectangle rectangleBottom = new Rectangle(xPos, recTopHeight + space, width, recBottomHeight);

        plane.getChildren().addAll(rectangleBottom);
        return new ArrayList<>(List.of(rectangleBottom));
    }

    public void moveObstacles(ArrayList<Rectangle> obstacles) {
        Iterator<Rectangle> iterator = obstacles.iterator();

        while (iterator.hasNext()) {
            Rectangle rectangle = iterator.next();
            moveRectangle(rectangle, -0.75);

            if (rectangle.getX() <= -rectangle.getWidth() && rectangle.getY() == 0) {
                iterator.remove();
                plane.getChildren().remove(rectangle);
            }
        }
    }

    private void moveRectangle(Rectangle rectangle, double amount){
        rectangle.setX(rectangle.getX() + amount);
    }

}

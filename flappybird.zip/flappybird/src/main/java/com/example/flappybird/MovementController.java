package com.example.flappybird;

import javafx.animation.AnimationTimer;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.fxml.FXML;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.AnchorPane;

public class MovementController {
    private BooleanProperty wPressed = new SimpleBooleanProperty();
    private BooleanProperty aPressed = new SimpleBooleanProperty();
    private BooleanProperty sPressed = new SimpleBooleanProperty();


    private BooleanBinding keyPressed = wPressed.or(aPressed).or(sPressed);

    private int movementVariable = 2;

    @FXML
    private ImageView sprite;

    @FXML
    private AnchorPane scene;

    public void makeMovable(ImageView sprite, AnchorPane scene){
        this.sprite = sprite;
        this.scene = scene;

        movementSetup();

        keyPressed.addListener(((observableValue, aBoolean, t1) -> {
            if(!aBoolean){
                timer.start();
            } else {
                timer.stop();
            }
        }));
    }

    AnimationTimer timer = new AnimationTimer() {
        @Override
        public void handle(long timestamp) {
            if(sPressed.get()) {
                sprite.setLayoutY(sprite.getLayoutY() - movementVariable);
            }

            if(wPressed.get()){
                sprite.setLayoutY(sprite.getLayoutY() + movementVariable);
            }

            if(aPressed.get()){
                sprite.setLayoutX(sprite.getLayoutX() + movementVariable);
            }

        }
    };

    private void movementSetup(){
        scene.setOnKeyPressed(e -> {
            if(e.getCode() == KeyCode.DOWN) {
                wPressed.set(true);
            }

            if(e.getCode() == KeyCode.RIGHT) {
                aPressed.set(true);
            }

            if(e.getCode() == KeyCode.UP) {
                sPressed.set(true);
            }
        });

        scene.setOnKeyReleased(e ->{
            if(e.getCode() == KeyCode.DOWN) {
                wPressed.set(false);
            }

            if(e.getCode() == KeyCode.RIGHT) {
                aPressed.set(false);
            }

            if(e.getCode() == KeyCode.UP) {
                sPressed.set(false);
            }
        });
    }
}

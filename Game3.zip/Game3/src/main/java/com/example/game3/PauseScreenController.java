// PauseScreenController.java
package com.example.game3;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;

public class PauseScreenController {

    public Button saveButton;
    public Button exitButton;
    @FXML
    private Button resumeButton;

    @FXML
    private void resumeGame(ActionEvent event) {
        // Get the stage (window) of the pause screen
        Stage pauseStage = (Stage) resumeButton.getScene().getWindow();

        // Close the pause screen
        pauseStage.close();

        // Resume the main game
        Controller.resumeGame();
    }

    @FXML
    private void pressed(KeyEvent event) {
        if (event.getCode().equals(KeyCode.P)) {
            // Handle the "P" key press to resume the main game
            Stage pauseStage = (Stage) resumeButton.getScene().getWindow();
            pauseStage.close();
            Controller.resumeGame();
        } else if (event.getCode().equals(KeyCode.R)) {
            // Handle the "R" key press to close the pause menu
            Stage pauseStage = (Stage) resumeButton.getScene().getWindow();
            pauseStage.close();
        }
    }
    @FXML
    private void exitGame(ActionEvent event) {
        // Close all screens and exit the application
        System.exit(0);
    }
}

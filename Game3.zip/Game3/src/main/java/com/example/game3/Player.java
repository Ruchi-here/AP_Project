package com.example.game3;

import javafx.scene.image.ImageView;

public class Player {
    private ImageView imageView;
    private double x;
    private double y;

    public Player(ImageView imageView, double initialX, double initialY) {
        this.imageView = imageView;
        this.x = initialX;
        this.y = initialY;
        this.imageView.setLayoutX(initialX);
        this.imageView.setLayoutY(initialY);
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public void setX(double x) {
        this.x = x;
        imageView.setLayoutX(x);
    }

    public void setY(double y) {
        this.y = y;
        imageView.setLayoutY(y);
    }

    public ImageView getImageView() {
        return imageView;
    }

    public void translateX(double deltaX) {
        setX(getX() + deltaX);
    }

    public void translateY(double deltaY) {
        setY(getY() + deltaY);
    }
}

package com.example.game3;

import javafx.animation.PauseTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;

public class GameOverController {

    public Button reviveButton;
    public Button exitButton;
    // You can add logic for handling the Game Over screen here if needed

    @FXML
    public void initialize() {
        // This method is automatically called when the FXML is loaded
        // You can add additional initialization logic here
    }

    public void reviveGame(ActionEvent actionEvent) {
        // Set the revivedGame flag to true
        Controller.setRevivedGame(true);

        // Close the Game Over screen
        closeGameOverScreen();

        // Restart the game after a short delay
        restartGameWithDelay();
    }

    private void closeGameOverScreen() {
        // Close the Game Over screen
        Stage currentStage = (Stage) reviveButton.getScene().getWindow();
        currentStage.close();
    }

    @FXML
    private void exitGame(ActionEvent event) {
        // Close all screens and exit the application
        System.exit(0);
    }

    private void restartGameWithDelay() {
        // Pause briefly to allow the Game Over screen to close
        PauseTransition pause = new PauseTransition(Duration.seconds(0.5)); // Adjust the duration as needed
        pause.setOnFinished(event -> {
            // Restart the game
            try {
                restartGame();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        pause.play();
    }

    private void restartGame() throws IOException {
        // Create an instance of the Controller class
        Controller controller = new Controller();

        // Call the restartGame method on the instance
        controller.restartGame();
    }

}
